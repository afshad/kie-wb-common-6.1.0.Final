package org.kie.workbench.common.screens.projecteditor.client.forms;

public interface DependencySelectorPresenter {

    void onPathSelection( String pathToDependency );
}
