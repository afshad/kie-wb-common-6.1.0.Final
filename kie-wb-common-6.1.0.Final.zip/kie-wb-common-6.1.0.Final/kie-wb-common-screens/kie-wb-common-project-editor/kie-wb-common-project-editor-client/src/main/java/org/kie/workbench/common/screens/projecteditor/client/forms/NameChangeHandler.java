package org.kie.workbench.common.screens.projecteditor.client.forms;

public interface NameChangeHandler {

    void onChange( String newName );

}
