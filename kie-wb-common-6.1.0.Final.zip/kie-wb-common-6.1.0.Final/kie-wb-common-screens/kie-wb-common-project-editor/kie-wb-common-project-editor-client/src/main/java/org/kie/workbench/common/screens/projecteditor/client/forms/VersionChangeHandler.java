package org.kie.workbench.common.screens.projecteditor.client.forms;

public interface VersionChangeHandler {

    void onChange( String newVersion );

}
