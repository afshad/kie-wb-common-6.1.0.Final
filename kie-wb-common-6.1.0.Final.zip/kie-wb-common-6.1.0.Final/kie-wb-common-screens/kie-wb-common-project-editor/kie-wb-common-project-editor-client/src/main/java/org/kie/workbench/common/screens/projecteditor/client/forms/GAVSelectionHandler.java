package org.kie.workbench.common.screens.projecteditor.client.forms;

import org.guvnor.common.services.project.model.GAV;

public interface GAVSelectionHandler {

    void onSelection(GAV gav);

}
