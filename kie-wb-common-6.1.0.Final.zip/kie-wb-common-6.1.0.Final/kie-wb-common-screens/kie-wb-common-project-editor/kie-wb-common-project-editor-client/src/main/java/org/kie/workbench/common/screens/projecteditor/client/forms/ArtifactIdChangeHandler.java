package org.kie.workbench.common.screens.projecteditor.client.forms;

public interface ArtifactIdChangeHandler {

    void onChange(String newArtifactId);

}
