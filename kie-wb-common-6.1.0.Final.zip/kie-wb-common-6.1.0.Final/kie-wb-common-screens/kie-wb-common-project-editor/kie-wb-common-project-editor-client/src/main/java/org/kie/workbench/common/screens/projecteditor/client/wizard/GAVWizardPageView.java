package org.kie.workbench.common.screens.projecteditor.client.wizard;

import com.google.gwt.user.client.ui.IsWidget;

public interface GAVWizardPageView
        extends IsWidget {
}
