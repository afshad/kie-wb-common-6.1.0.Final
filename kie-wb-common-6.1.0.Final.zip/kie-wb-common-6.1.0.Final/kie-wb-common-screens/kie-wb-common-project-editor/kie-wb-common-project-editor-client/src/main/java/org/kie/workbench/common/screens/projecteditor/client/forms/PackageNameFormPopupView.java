package org.kie.workbench.common.screens.projecteditor.client.forms;

import org.kie.workbench.common.widgets.client.popups.text.FormPopupView;

public interface PackageNameFormPopupView
        extends FormPopupView {

    void addItem(String packageName);
}
