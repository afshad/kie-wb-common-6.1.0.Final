package org.kie.workbench.common.screens.projecteditor.client.forms;

public interface GroupIdChangeHandler {

    void onChange( String newGroupId );

}
