package org.kie.workbench.common.screens.projecteditor.client.forms;

import com.google.gwt.event.shared.EventHandler;

public interface RemoveItemHandler
        extends EventHandler {

    void onRemoveItem(RemoveItemEvent event);
}
