package t1p2;

public class Pojo2 {

}
